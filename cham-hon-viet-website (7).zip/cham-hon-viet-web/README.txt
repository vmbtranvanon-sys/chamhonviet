CHẠM HỒN VIỆT – WEBSITE NGÀY VĂN HÓA VIỆT NAM 24/11/2026

MỞ WEBSITE TRÊN MÁY TÍNH
1. Giải nén thư mục cham-hon-viet-web.
2. Mở file index.html bằng Chrome, Edge hoặc Firefox.
3. Website có thể chạy trực tiếp, không cần cài đặt. Cần Internet để tải font Be Vietnam Pro và Playfair Display; nếu không có mạng, website vẫn hiển thị bằng font thay thế.

ĐƯA WEBSITE LÊN MẠNG MIỄN PHÍ (GITHUB PAGES)
1. Tạo tài khoản tại https://github.com nếu chưa có.
2. Tạo repository mới, ví dụ: cham-hon-viet.
3. Upload toàn bộ nội dung trong thư mục này (giữ nguyên thư mục assets và file index.html).
4. Vào Settings > Pages.
5. Ở phần Build and deployment, chọn Deploy from a branch; Branch: main; Folder: /(root), rồi Save.
6. Chờ GitHub Pages triển khai và lấy đường dẫn website hiển thị tại mục Pages.

CẦN CHỈNH TRƯỚC KHI NỘP
- Mở index.html, tìm dòng “Thực hiện: ................................ · Lớp: ................” ở cuối trang và điền họ tên, lớp.
- Nội dung các mốc lịch sử được biên soạn theo định hướng đề bài và sản phẩm tham khảo; nên đối chiếu lại cách diễn đạt ngày 24/11/2026 với thông báo chính thức của giáo viên/nhà trường trước khi công bố.

CẤU TRÚC
index.html              Trang web, nội dung, giao diện và tương tác
assets/hero-ao-dai.png  Hình ảnh chủ đạo
README.txt              Hướng dẫn sử dụng và xuất bản
